<?php 
session_start();
require 'connection.php';
$status="";
if (isset($_POST['product_code']) && $_POST['product_code']!=""){
$code = $_POST['product_code'];
$result = mysqli_query($con,"SELECT * FROM `product_items` WHERE `product_code`='$code'");
$row = mysqli_fetch_assoc($result);
$name = $row['product_name'];
$code = $row['product_code'];
$price = $row['product_price'];
$image = $row['product_image'];

$cartArray = array(
	$code=>array(
	'product_name'=>$name,
	'product_code'=>$code,
	'product_price'=>$price,
	'quantity'=>$_POST['quantity'],
	'product_image'=>$image)
);

if(empty($_SESSION["shopping_cart"])) {
	$_SESSION["shopping_cart"] = $cartArray;
  $status = '<div class="w3-container w3-twothird w3-small" style="margin:10px 0px;color:green;border-top:1.5px solid  #4da6ff;height:60px;background-color: #cce6ff;margin-left:300px;">
  <p>Product is added to your cart!</p>
  </div>';
}else{
	$array_keys = array_keys($_SESSION["shopping_cart"]);
	if(in_array($code,$array_keys)) {
		$status ='<div class="w3-container w3-twothird w3-small" style="margin:10px 0px;color:red;border-top:1.5px solid  #4da6ff;height:60px;background-color: #cce6ff;margin-left:300px;">
    <p>Product is already added to your cart!</p>
    </div>';	
	} else {
	$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
	$status = '<div class="w3-container w3-twothird w3-small" style="margin:10px 0px;color:green;border-top:1.5px solid  #4da6ff;height:60px;background-color: #cce6ff;margin-left:300px;">
  <p>Product is added to your cart!</p>
  </div>';
	}

	}
}
?>

<html>
<head>
<title>Computers</title>
<link rel="stylesheet" href="computers.css">
<link rel="stylesheet" href="Css/material-icons.css">
<link rel="stylesheet" href="w3.css">
<link rel="stylesheet" href="./Css/w3-themes.css">
<style>
.searchbtn{
  margin-left: 700px;
  margin-top: -40px;
}
#searchText{
  width: 400px;
  height: 50px;
  padding: 0;
  line-height: 12px;
  margin-left: 350px;
  margin-top: -45px;
}
#MENU ::placeholder{
  padding-left: 30px;
}

</style>
</head>
<body>

<div class="w3-container w3-black" id="TopBar">
            <h4><strong style="color: white;">Mars</strong></h4>
            <p id="register"><a style="border-right: 1px solid white;padding-right: 5px;" href="sign_up.html">REGISTER</a></p>
            <p id="register1"><a href="##">MY ACCOUNT</a></p>
            <p id="register2">
                <!--Login Page-->
                <a  onclick="myModal()">LOG IN</a>
                <div id="id01" class="w3-modal">

                <div class="w3-modal-content w3-animate-zoom w3-card-4 w3-round" style="width: 33%;top: -12%;">

                <header class="w3-container" id="LoginContainer">
                <h2 style=" font-weight: bolder;margin-top: 10px;margin-left: 100px;font-family:Segoe UI, Tahoma, Geneva, 'Verdana', sans-serif;color: blue;">
                <strong style="color: black;">Mountain</strong> Eagle.</h2>
                </header>
                <div class="w3-container">
                <img src="./Avatar/undraw_hologram_fjwp (1).png" style="width: 200px;margin-left: 85px;">
                <form class="w3-container" method="POST" action="" style="margin-bottom: 40px;">
                <label class="w3-label" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;font-weight:bolder;color: grey;"><i class="material-icons icon-login">supervisor_account</i>Username:</label>
                <input class="w3-input w3-round" type="text" placeholder="Your first name" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;width: 100%;">
                <label class="w3-label" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;font-weight: bolder;color: grey;"><i class="material-icons icon-login">lock</i>Password :</label>
                <input class="w3-input  w3-round" type="password" placeholder="Your password" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;width: 100%;"><p class="" style="margin-left: 205px;font-size: small;color: grey;">Forget password?Reset </p>
                <button class="w3-btn w3-round  w3-border w3-border-blue w3-text-blue" type="submit" style="margin-top: 5px; margin-left: 5px;width: 100%;">Log in</button>
                <button onclick="Close()" class="w3-btn w3-round w3-border w3-border-blue w3-text-blue" id="Close" style="margin-left: 5px;margin-top:8px; width: 100%;">Cancel</button>
                </form>
                </div>
                </div>
                <!--Login Page End-->
                </div>
                </p>
</div>
        
                <!--NAvigation Bar--->
<div class="w3-container w3-blue" id="Nav">
               <ul id="homeNav">
               <li><a href="About.html">About</a></li>
               <li><a href="Contact_us.html">Contact Us</a></li>
               <li><a href="Services.html">Services</a></li>
               <li><a href="shoppingcart.php">Shopping Cart</a>
               </li>
               <li><a href="Home.html">Home</a></li>
               </ul>
</div>
               <!--End Of Navgaton Bar-->
               <br>
               <h3  class="w3-blue w3-center" style="width: 300px;">MARS COMPUTERS</h3>
               <div class="w3-container" id="MENU">
               <input id="searchText" class="w3-input w3-border" name="search" placeholder="Search Your Products Here...">
               <p class="searchbtn"><i style="font-size: xx-large; color: #C8C8C8 ;" class="material-icons">search</i></p>
               <button class="w3-btn w3-blue" style="width: 160px;margin-top: -57px;margin-left: 750.2px;height: 50px;">SEARCH</button>
               <button class="w3-btn w3-theme-d5p w3-center-align" style="width: 180px;margin-top: -56px;margin-left: 950px;height: 50px;"><img src="ic_dehaze_white_24dp.png" style="float: left;" >WISH LIST</button>
               </div>
               <hr>
               <!--Computers Items---->
            
<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="w3-container w3-right-align" style="margin-right:40px;" id="cart" >
<a href="shoppingcart.php" style="text-decoration:none;font-size:small;font-weight:lighter;"><img src="ic_local_grocery_store_black_18dp.png" />Shopping Cart</a>
<span class="w3-badge w3-tiny w3-blue"><?php echo $cart_count; ?></span>
</div>
<?php
}
?>

<div>
<?php echo $status; ?>
<?php
$result = mysqli_query($con,"SELECT * FROM `product_items`");
while($row = mysqli_fetch_assoc($result)){?>
        <div class='w3-container w3-border-bottom w3-twothird' style="margin-left: 300px;">
	      <form method='post' action='computers.php?action=code=<?php echo $row['product_code'];?>& itemsName=<?php echo $row['product_name'];?>'>
	      <input type='hidden' name='product_code' value="<?php echo $row['product_code'];?>" />
        <div style='color: #888888;font-size:small;font-weight:lighter;' class='image'><img style='width:150px;' src="<?php echo $row['product_image'];?>"/><?php echo $row['product_name'];?></div>
        <span class="w3-third w3-small" style="margin-left: 350px;margin-top:-80px;color: #888888;"><?php echo $row['product_description'];?></span>
        <input style='height:20px;width:30px;margin-left:700px;margin-top:-50px;' class='w3-input w3-border' type='text' name='quantity' value='1'>
        <div style='color: #888888;font-size:small;font-weight:lighter;margin-left:765px;margin-top:-40px;'><?php echo $row['product_code'];?></div>
        <div style='font-size:small;font-weight:lighter;margin-left:765px;'class='w3-text-red' class='price'><?php echo "$".$row['product_price'];?></div>
       <br>
       <br>
        <input style="margin-left:765px;" class='w3-btn w3-yellow w3-small'  type='submit' class='buy' value='Add to Cart'/>
        <input style="margin-left:650px;margin-top:-34px;"  class="w3-btn w3-theme-d5p w3-small" type="submit" value="Wish List"/>
        </form>
        </div>
        <?php
        }
        mysqli_close($con);
        ?>
</div>         
</body>
</html>
