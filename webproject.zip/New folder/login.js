function myModal(){
    document.getElementById('id01').style.display ="block"; 
}

function Close(){
   document.getElementById('id01').style.display ="none";
}