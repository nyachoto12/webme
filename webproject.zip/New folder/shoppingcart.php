<?php 
session_start();
$status="";
if (isset($_POST['action']) && $_POST['action']=="remove"){
if(!empty($_SESSION["shopping_cart"])) {
	foreach($_SESSION["shopping_cart"] as $key => $value) {
		if($_POST["product_code"] == $key){
		unset($_SESSION["shopping_cart"][$key]);
		$status = '<div id="Con" class="w3-container w3-small" style="margin:10px 0px;border-top:1.5px solid  #4da6ff;height:60px;background-color: #cce6ff;margin-left:244px;width:1100px;">
    <p style="color:red;margin-left:50px;">Product removed from your cart!</p>
    </div>';
		}
		if(empty($_SESSION["shopping_cart"]))
		unset($_SESSION["shopping_cart"]);
			}		
		}
}

if (isset($_POST['action']) && $_POST['action'] == $_POST['product_code']){
  foreach($_SESSION["shopping_cart"] as &$value){
    if($value['product_code'] === $_POST["product_code"]){
        $value['quantity'] = $_POST["quantity"];
        break; // Stop the loop after we've found the product
    }
}
  	
}
?>
<html>
<head>
<title>Shopping Cart</title>
<link rel="stylesheet" href="w3.css">
<link rel="stylesheet" href="shoppingcart.css">
<link rel="stylesheet" href="Css/material-icons.css">
<link rel="stylesheet" href="./Css/w3-themes.css">
</head>
<body>
<div class="w3-container w3-black" id="TopBar">
            <h4><strong style="color: white;">Mars</strong></h4>
            <p id="register"><a style="border-right: 1px solid white;padding-right: 5px;" href="sign_up.html">REGISTER</a></p>
            <p id="register1"><a href="##">MY ACCOUNT</a></p>
            <p id="register2">
                <!--Login Page-->
                <a  onclick="myModal()">LOG IN</a>
                <div id="id01" class="w3-modal">

                <div class="w3-modal-content w3-animate-zoom w3-card-4 w3-round" style="width: 33%;top: -12%;">

                <header class="w3-container" id="LoginContainer">
                <h2 style=" font-weight: bolder;margin-top: 10px;margin-left: 100px;font-family:Segoe UI, Tahoma, Geneva, 'Verdana', sans-serif;color: blue;">
                <strong style="color: black;">Mountain</strong> Eagle.</h2>
                </header>
                <div class="w3-container">
                <img src="./Avatar/undraw_hologram_fjwp (1).png" style="width: 200px;margin-left: 85px;">
                <form class="w3-container" method="POST" action="" style="margin-bottom: 40px;">
                <label class="w3-label" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;font-weight:bolder;color: grey;"><i class="material-icons icon-login">supervisor_account</i>Username:</label>
                <input class="w3-input w3-round" type="text" placeholder="Your first name" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;width: 100%;">
                <label class="w3-label" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;font-weight: bolder;color: grey;"><i class="material-icons icon-login">lock</i>Password :</label>
                <input class="w3-input  w3-round" type="password" placeholder="Your password" style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;width: 100%;"><p class="" style="margin-left: 205px;font-size: small;color: grey;">Forget password?Reset </p>
                <button class="w3-btn w3-round  w3-border w3-border-blue w3-text-blue" type="submit" style="margin-top: 5px; margin-left: 5px;width: 100%;">Log in</button>
                <button onclick="Close()" class="w3-btn w3-round w3-border w3-border-blue w3-text-blue" id="Close" style="margin-left: 5px;margin-top:8px; width: 100%;">Cancel</button>
                </form>
                </div>
                </div>
                <!--Login Page End-->
                </div>
                </p>
</div>
        
                <!--NAvigation Bar--->
<div class="w3-container w3-blue" id="Nav">
               <ul id="homeNav">
               <li><a href="About.html">About</a></li>
               <li><a href="Contact_us.html">Contact Us</a></li>
               <li><a href="Services.html">Services</a></li>
               <li><a href="shoppingcart.php">Shopping Cart</a>
               </li>
               <li><a href="Home.html">Home</a></li>
               </ul>
</div>
               <!--End Of Navgaton Bar-->
                <br>
                <hr>
               <!--Computers Items---->
<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="w3-container w3-right-align" style="margin-right:40px;" id="cart" >
<a  style="text-decoration:none;font-size:small;font-weight:lighter;"><img src="ic_local_grocery_store_black_18dp.png" />Shopping Cart</a>
<span class="w3-badge w3-tiny w3-blue"><?php echo $cart_count; ?></span>
</div>
<div id="Con" class="w3-container w3-small" style="margin:10px 0px;border-top:1.5px solid  #4da6ff;height:60px;background-color: #cce6ff;margin-left:244px;width:1100px;">
<p style="color: lightslategray;margin-left:50px;">Would you like some more goods?<a class="w3-hover-blue" style="margin-left: 600px;text-decoration:none;transition: 0.4s;" id="conshop" href="computers.php">Continue Shopping</a></p>

</div>
<?php
}
?>
<div class="w3-container">
<?php
if(isset($_SESSION["shopping_cart"])){
    $total_price = 0;
?>	
<table class="w3-table w3-pale-blue w3-bordered" style="margin-left: 228px;width:1100px;font-size:small;" >
<tbody>
<tr class="w3-blue">
<td></td>
<td style="text-align:left;">Name</td>
<td style="text-align:left;" width="5%">Code</td>
<td style="text-align:right;" width="5%">Quantity</td>
<td style="text-align:right;" width="6%">Unit Price</td>
<td style="text-align:right;" width="4%">Price</td>
<td style="text-align:centre;" width="5%">Remove</td>
</tr>	
<?php		
foreach ($_SESSION["shopping_cart"] as $product){
?>
<tr>
<td><img class="w3-round" src='<?php echo $product["product_image"]; ?>' width="80px"/></td>
<td><?php echo $product["product_name"]; ?></td>
<td><?php echo $product["product_code"]; ?></td>
<td><?php echo $product["quantity"];?></td>
<td><?php echo "$".$product["product_price"]; ?></td>
<td class="w3-text-green"><?php echo "$".$product["product_price"]*$product["quantity"]; ?></td>
<td><form method='post' action=''>
<input type='hidden' name='product_code' value="<?php echo $product["product_code"]; ?>"/>
<input type='hidden' name='action' value="<?php echo $product["quantity"];?>"/>
<input type='hidden' name='product_code' value="<?php echo $product["product_code"]; ?>" />
<input type='hidden' name='action' value="remove" />
<button class="w3-btn" style="width:50px;" type='submit' class='remove'><img  src="icon-delete.png"></button>
</form>
</td>
</tr>
<?php
$total_price += ($product["product_price"]*$product["quantity"]);
}
?>
<tr>
<td class="w3-right-align" colspan="5">
<strong class="w3-text-red">TOTAL PRICE: <?php echo "$".$total_price; ?></strong>
</td>
</tr>
<tr>
<td class="w3-right-align" colspan="5">
<strong class="w3-text-red">AMOUNT TO BE PAID: <?php echo "$".$total_price; ?></strong>
</td>
</tr>
</tbody>
</table>		
  <?php
}else{
	echo '<div id="Con" class="w3-container w3-small" style="margin:10px 0px;border-top:1.5px solid  #4da6ff;height:60px;background-color: #cce6ff;margin-left:230px;width:1100px;">
  <p style="color:green;margin-left:50px;">Your cart is Empty!</p>
  </div>';
	}
?>
</div>

<div style="clear:both;"></div>
<?php echo $status; ?>        
</div>
</body>
</html>
